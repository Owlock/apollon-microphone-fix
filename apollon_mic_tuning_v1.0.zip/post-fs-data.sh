#!/system/bin/sh
MODDIR="${0%/*}"
MODE="$(cat "$MODDIR/mode" 2>/dev/null | tr -d '[:space:]')"
LOG="$MODDIR/mount.log"
DST="/vendor/etc/mixer_paths_overlay_static.xml"
SRC="$MODDIR/files/mixer_paths_overlay_static.xml"

exec >>"$LOG" 2>&1
echo "=== $(date) ==="
echo "Active mode: $MODE"

DEVICE="$(getprop ro.product.device)"
PRODUCT="$(getprop ro.product.vendor.device)"

case "$DEVICE:$PRODUCT" in
    *apollo*|*apollon*)
        echo "Device verified: $DEVICE ($PRODUCT)"
        ;;
    *)
        echo "Refusing unsupported device: $DEVICE / $PRODUCT"
        exit 1
        ;;
esac

# Phase 1: Apply MIUI vendor Fluence & VoIP properties
if [ "$MODE" = "props" ] || [ "$MODE" = "both" ]; then
    echo "Applying Qualcomm Fluence & VoIP properties via resetprop -n..."
    resetprop -n ro.vendor.audio.sdk.fluencetype fluence
    resetprop -n persist.vendor.audio.fluence.voicecall true
    resetprop -n persist.vendor.audio.fluence.voicecomm true
    resetprop -n persist.vendor.audio.fluence.speaker true
    resetprop -n persist.vendor.audio.fluence.voicerec false
    resetprop -n persist.vendor.audio.fluence.tmic.enabled false
    resetprop -n vendor.audio.feature.fluence.enable true
    resetprop -n vendor.voice.path.for.pcm.voip true
    resetprop -n vendor.audio.feature.compr_voip.enable false
    echo "Properties applied successfully."
fi

# Phase 2: Bind-mount calibrated mixer overlay
if [ "$MODE" = "gains" ] || [ "$MODE" = "both" ]; then
    echo "Applying mixer overlay bind mount..."
    if [ ! -f "$DST" ]; then
        echo "Missing target: $DST"
        exit 1
    fi
    if [ ! -f "$SRC" ]; then
        echo "Missing replacement: $SRC"
        exit 1
    fi

    chmod 0644 "$SRC"
    chown 0:0 "$SRC"

    if command -v chcon >/dev/null 2>&1; then
        chcon --reference="$DST" "$SRC" 2>/dev/null || chcon u:object_r:vendor_configs_file:s0 "$SRC" 2>/dev/null
    fi

    mount -o bind "$SRC" "$DST" || {
        echo "Bind mount failed"
        exit 1
    }
    echo "Mounted successfully:"
    grep "mixer_paths_overlay_static.xml" /proc/self/mountinfo
    sha256sum "$SRC" "$DST"
fi
