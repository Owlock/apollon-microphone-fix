#!/system/bin/sh
MODDIR="${0%/*}"
MODE="$(cat "$MODDIR/mode" 2>/dev/null | tr -d '[:space:]')"
DST="/vendor/etc/mixer_paths_overlay_static.xml"
SRC="$MODDIR/files/mixer_paths_overlay_static.xml"

if [ "$MODE" = "gains" ] || [ "$MODE" = "both" ]; then
    # Ensure mount persists
    if ! grep -q "$DST" /proc/mounts 2>/dev/null; then
        mount -o bind "$SRC" "$DST"
    fi
fi
